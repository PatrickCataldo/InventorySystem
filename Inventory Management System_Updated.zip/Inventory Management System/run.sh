#!/bin/bash
   java -jar InventorySystem-1.0-SNAPSHOT.jar