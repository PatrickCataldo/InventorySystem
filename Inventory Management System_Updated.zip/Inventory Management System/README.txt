--------------------------------------------------------------
Inventory Management System Project
Author:		Patrick Cataldo
Last Modified:	9/8/2024
--------------------------------------------------------------

Hello! Thank you for downloading my project!

Here are the instructions to run the program:
--------------------------------------------------------------
WINDOWS USERS:
  - Double-click the "run.bat" file

MACOS / LINUX USERS:
  - Open a terminal in the directory containing the file
  - Run the following command:
	chmod +x run.sh
--------------------------------------------------------------

Once again, Thank you for trying my project!
If you have any comments, questions, suggestions, or tips,
please contact me through my GitHub website!
--------------------------------------------------------------
- Patrick Cataldo
